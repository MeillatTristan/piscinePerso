git check-ignore *
